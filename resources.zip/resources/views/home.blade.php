@extends('layouts.app')
@section('title','Homepage · Peta Kemiripan Menteri')

@section('content')
<section class="position-relative mb-3">

  {{-- Header + tombol --}}
  <div class="glass-soft p-3 p-lg-4 d-flex align-items-center justify-content-between flex-wrap gap-2">
    <div class="flex-grow-1 text-center">
      <h1 class="title-main m-0">Peta Kemiripan Menteri</h1>
    </div>

    <div class="d-flex gap-2 ms-lg-auto">
      <a href="{{ route('compare') }}" class="btn-pill-primary">
        Bandingkan Menteri
      </a>
      <a href="{{ route('menteri.create') }}" class="btn-pill-primary">
        Masukkan Dataku
      </a>
    </div>
  </div>

  {{-- UMAP area with left dock for full card --}}
  <div class="umap-shell mt-3">
    {{-- Left dock (hidden until click) --}}
    <aside id="dock-left" class="dock-left d-none"></aside>

    {{-- Map --}}
    <div class="map-wrap glass-soft position-relative">
      <div class="map-hint">
        <span>Hover titik → lihat ringkas</span>
        <span>Click titik → kunci & scroll detail</span>
        <span>Scroll mouse → zoom</span>
      </div>
      <div id="umap-canvas"></div>
    </div>
  </div>

</section>
@endsection

@push('scripts')
@vite('resources/js/umap-home.js')
@endpush
