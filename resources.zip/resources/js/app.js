import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';

import Alpine from "alpinejs";
window.Alpine = Alpine;
Alpine.start();

import * as d3 from "d3";
window.d3 = d3;

import tippy from "tippy.js";
import "tippy.js/dist/tippy.css";
window.tippy = tippy;

// Global helper warna (kecuali hitam)
window.randomColorNotBlack = function () {
  const palette = [
    "#FF5C8A", "#7C5CFF", "#00D1FF", "#00E5A8",
    "#FFC857", "#FF8A00", "#A1FF0A", "#FF4D4D",
    "#5CE1E6", "#9B5DE5", "#F15BB5", "#FEE440"
  ];
  return palette[Math.floor(Math.random() * palette.length)];
};
