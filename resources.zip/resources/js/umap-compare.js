import * as d3 from "d3";
import tippy from "tippy.js";

(async function () {
  const canvas = document.getElementById("umap-canvas");
  const width = canvas.clientWidth;
  const height = canvas.clientHeight;

  const svg = d3.select(canvas)
    .append("svg")
    .attr("width", width)
    .attr("height", height);

  const res = await fetch("/api/menteri");
  const data = await res.json();

  const x = d3.scaleLinear().domain(d3.extent(data, d => d.umap_x)).range([30, width-30]);
  const y = d3.scaleLinear().domain(d3.extent(data, d => d.umap_y)).range([height-30, 30]);

  let compareMode = false;
  let selected = [];

  window.setCompareMode = (v)=>{ 
    compareMode = v; 
    window.resetCompare();
  };

  window.resetCompare = ()=>{
    selected = [];
    document.getElementById("compare-cards").classList.add("d-none");
    nodes.attr("fill", d => d.color||randomColorNotBlack()).attr("r",5);
  };

  const nodes = svg.selectAll("circle")
    .data(data).enter().append("circle")
    .attr("cx", d=>x(d.umap_x))
    .attr("cy", d=>y(d.umap_y))
    .attr("r", 5)
    .attr("fill", d => d.color||randomColorNotBlack())
    .style("cursor","pointer");

  function cardHTML(d){
    return `
      <div class="d-flex gap-2 align-items-center mb-2">
        <img src="${d.foto_url||''}" onerror="this.style.display='none'"
          style="width:56px;height:56px;object-fit:cover;border-radius:12px;">
        <div>
          <div class="fw-bold">${d.nama}</div>
          <div style="color:var(--muted);font-size:.85rem">${d.kementerian}</div>
        </div>
      </div>
      <div class="info-scroll" id="scroll-${d.id}">
        ${d.detail_html || '<small style="color:var(--muted)">Detail belum tersedia</small>'}
      </div>
    `;
  }

  function renderCompare(){
    if (selected.length < 2) return;
    const [a,b] = selected;
    document.getElementById("card-left").innerHTML = cardHTML(a);
    document.getElementById("card-right").innerHTML = cardHTML(b);
    document.getElementById("compare-cards").classList.remove("d-none");

    // sync scroll
    const sa = document.getElementById(`scroll-${a.id}`);
    const sb = document.getElementById(`scroll-${b.id}`);
    let syncing = false;

    sa.addEventListener("scroll", ()=>{
      if(syncing) return; syncing=true;
      sb.scrollTop = sa.scrollTop; syncing=false;
    });
    sb.addEventListener("scroll", ()=>{
      if(syncing) return; syncing=true;
      sa.scrollTop = sb.scrollTop; syncing=false;
    });
  }

  nodes.on("mouseenter", function(event,d){
    if(!compareMode) return;
    // hover info kecil tanpa scroll (simple tippy)
    tippy(this, {
      content: `<strong>${d.nama}</strong><br><small>${d.kementerian}</small>`,
      allowHTML:true,
      trigger:"manual",
      placement:"top",
    }).show();
  });

  nodes.on("click", function(event,d){
    if(!compareMode) return;

    if(selected.find(s=>s.id===d.id)) return; // jangan pilih yg sama
    if(selected.length===2) return;

    selected.push(d);

    nodes
      .attr("fill", n => selected.find(s=>s.id===n.id) ? "#000000" : (n.color||randomColorNotBlack()))
      .attr("r", n => selected.find(s=>s.id===n.id) ? 7 : 5);

    if(selected.length===2) renderCompare();
  });
})();
