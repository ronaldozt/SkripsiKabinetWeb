import * as d3 from "d3";
import tippy from "tippy.js";

(async function () {
  const canvas = document.getElementById("umap-canvas");
  const dockLeft = document.getElementById("dock-left");

  const width = canvas.clientWidth;
  const height = canvas.clientHeight;

  // SVG root
  const svg = d3.select(canvas)
    .append("svg")
    .attr("width", width)
    .attr("height", height);

  // Layer untuk zoom/pan
  const g = svg.append("g").attr("class", "zoom-layer");

  // Fetch dari API DB
  const res = await fetch("/api/menteri");
  const data = await res.json();

  // Jika data kosong, stop
  if (!data.length) {
    canvas.innerHTML = "<div class='text-center p-5 text-muted'>Data UMAP belum tersedia</div>";
    return;
  }

  // Scale UMAP coords
  const x = d3.scaleLinear()
    .domain(d3.extent(data, d => d.umap_x)).nice()
    .range([30, width - 30]);

  const y = d3.scaleLinear()
    .domain(d3.extent(data, d => d.umap_y)).nice()
    .range([height - 30, 30]);

  // Warna cluster random (hindari hitam)
  const palette = [
    "#FF6384","#36A2EB","#FFCE56","#4BC0C0","#9966FF",
    "#FF9F40","#00C49A","#F15BB5","#00BBF9","#9BDEAC"
  ];
  const getColor = (d, i) => d.color || palette[i % palette.length];

  let lockedId = null;
  let tipInstance = null;

  // ===== Tooltip template (hover, non-scroll) =====
  const hoverTemplate = (d) => `
    <div class="hover-glass info-card" style="width:300px;">
      <div class="d-flex gap-2 align-items-center mb-2">
        <div class="flex-grow-1">
          <div style="font-weight:800">${d.nama}</div>
          <div style="font-size:.85rem;color:#555">${d.kementerian||'-'}</div>
        </div>
        <img src="${d.foto_url||''}" onerror="this.style.display='none'"
             style="width:44px;height:44px;border-radius:10px;object-fit:cover;background:#fff;">
      </div>

      <div class="kv">
        <div class="k">Jenis Kelamin</div><div class="v">${d.jenis_kelamin||'-'}</div>
        <div class="k">Umur</div><div class="v">${d.umur||'-'}</div>
        <div class="k">Partai</div><div class="v">${d.partai||'-'}</div>
        <div class="k">Pendidikan S1</div><div class="v">${d.pendidikan_s1||'-'}</div>
      </div>

      <div class="mt-2" style="font-size:.75rem;color:#666">
        Klik titik untuk lihat detail penuh
      </div>
    </div>
  `;

  function showHover(d, node){
    if (lockedId && lockedId !== d.id) return;
    if (tipInstance) tipInstance.destroy();

    tipInstance = tippy(node, {
      content: hoverTemplate(d),
      allowHTML: true,
      interactive: true,
      trigger: "manual",
      placement: "right",
      theme: "umap-hover",
    });
    tipInstance.show();
  }

  // ===== Full detail card (left dock) =====
  function renderFullCard(d, color){
    dockLeft.innerHTML = `
      <img class="detail-photo" src="${d.foto_url||''}" onerror="this.style.display='none'">
      <div class="detail-title">${d.nama}</div>
      <div class="detail-sub">${d.kementerian||'-'}</div>

      <div class="detail-scroll">
        <div class="kv">
          <div class="k">Jenis Kelamin</div><div class="v">${d.jenis_kelamin||'-'}</div>
          <div class="k">Provinsi Lahir</div><div class="v">${d.provinsi_lahir||'-'}</div>
          <div class="k">Umur</div><div class="v">${d.umur||'-'}</div>
          <div class="k">Partai</div><div class="v">${d.partai||'-'}</div>
          <div class="k">Jabatan Rangkap</div><div class="v">${d.jabatan_rangkap||'-'}</div>

          <div class="k">DPR/MPR</div><div class="v">${d.dpr_mpr||'-'}</div>
          <div class="k">Militer/Polisi</div><div class="v">${d.militer_polisi||'-'}</div>

          <div class="k">Lokasi SMA</div><div class="v">${d.lokasi_sma||'-'}</div>
          <div class="k">Lokasi S1</div><div class="v">${d.lokasi_s1||'-'}</div>
          <div class="k">Lokasi S2</div><div class="v">${d.lokasi_s2||'-'}</div>
          <div class="k">Lokasi S3</div><div class="v">${d.lokasi_s3||'-'}</div>

          <div class="k">Jurusan S1</div><div class="v">${d.pendidikan_s1||'-'}</div>
          <div class="k">Jurusan S2/S3</div><div class="v">${d.pendidikan_s2s3||'-'}</div>

          <div class="k">Korupsi</div><div class="v">${d.korupsi_level||'-'}</div>
          <div class="k">Harta</div><div class="v">${d.harta_level||'-'}</div>
        </div>
      </div>

      <button class="btn-cta-compare" id="btn-mirip">
        Menteri Termirip Denganku
      </button>
    `;

    dockLeft.classList.remove("d-none");
  }

  // ===== Dots =====
  const nodes = g.selectAll("circle")
    .data(data)
    .enter()
    .append("circle")
    .attr("cx", d => x(d.umap_x))
    .attr("cy", d => y(d.umap_y))
    .attr("r", 5)
    .attr("fill", (d,i) => getColor(d,i))
    .attr("opacity", 0.9)
    .style("cursor","pointer");

  // Hover effect (dot membesar)
  nodes
    .on("mouseenter", function (event, d) {
      d3.select(this).attr("r", lockedId === d.id ? 8 : 7);
      showHover(d, this);
    })
    .on("mouseleave", function () {
      d3.select(this).attr("r", (n) => lockedId === n.id ? 8 : 5);
      if (!lockedId && tipInstance) tipInstance.hide();
    })
    .on("click", function (event, d) {
      lockedId = d.id;

      // reset warna semua dot kecuali locked
      nodes
        .attr("fill", (n,i) => n.id === lockedId ? "#000000" : getColor(n,i))
        .attr("r", (n) => n.id === lockedId ? 8 : 5);

      // matikan tooltip hover & render full card
      if (tipInstance) tipInstance.destroy();
      renderFullCard(d);

    });

  // ===== Zoom & pan (scroll follow mouse) =====
  const zoom = d3.zoom()
    .scaleExtent([0.7, 8])
    .on("zoom", (event) => {
      g.attr("transform", event.transform);
    });

  svg.call(zoom);

  // Optional: double click reset
  svg.on("dblclick.zoom", null);
  svg.on("dblclick", () => {
    svg.transition().duration(300).call(zoom.transform, d3.zoomIdentity);
  });

})();
